
class SenseAPITimeoutException(Exception):
    pass

class SenseAuthenticationException(Exception):
    pass

class SenseWebsocketException(Exception):
    pass
